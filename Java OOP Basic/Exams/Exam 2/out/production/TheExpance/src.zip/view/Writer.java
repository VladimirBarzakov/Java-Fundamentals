package view;

public class Writer {

    public void writeLine(String message){
        System.out.println(message);
    }

    public void write(String message){
        System.out.print(message);
    }
}
