package animal;

public abstract class Feline extends Mammal {


    public Feline(String animalType, String animalName, double animalWeight, String livingRegion) {
        super(animalType, animalName, animalWeight, livingRegion);
    }
}
